#include <stdio.h>
#include <stdlib.h>


// enuciado confuso

/*
Faça um programa para determinar a próxima jogada em um Jogo da Velha. Assumir 
que o tabuleiro e representado por uma matriz de 3 x 3, onde cada posição representa 
uma das casas do tabuleiro. A matriz pode conter os seguintes valores -1, 0, 1 
representando respectivamente uma casa contendo uma peça minha (-1), uma casa 
vazia do tabuleiro (0), e uma casa contendo uma peça do meu oponente (1). Exemplo:
*/
