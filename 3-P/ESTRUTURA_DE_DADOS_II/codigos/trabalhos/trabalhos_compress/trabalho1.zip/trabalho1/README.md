


Utilizando a linguagem de programação C, implemente as funções descritas abaixo usando a representação em Matriz e Lista de adjacências.

- Implementação de algumas das operações mais comuns
  - criar grafo vazio
  - inserir aresta
  - retirar aresta
  - verificar se existe aresta
  - obter lista de vértices adjacentes a um determinado vertice
     - Lista está vazia?
     - retornar primeiro vértice da lista
     - retornar próximo vértice adjascente da lista
  - imprimir grafo


- Como compilar ?
   gcc -Wall nome_do_arquivo.c -lm

- executar
   ./a.out