1) Calcule um vetor booleano isSink[], indexado pelos vértices, que identifique os sorvedouros de um grafo. Repita com fontes no lugar se sourvedouros. (Fontes e sorvedouros) 

2) Escreva uma função GRAPHequal() que decida se dois grafos, digamos G e H, são iguais. (Teste de igualdade) 

3) Escreva funções que convertam uma representação de um grafo em outra. Por exemplo, convertam uma representação por matriz de adjacências na representação por listas de adjacência. (Transformação de uma representação em outra)

 4) Escreva uma função UGRAPHdegrees() que receba um grafo não-dirigido e devolva um vetor g[], indexado por vértices, tal que g[v] é o grau do vértice v. (Grau) 

5) Escreva uma função que construa um grafo completo com V vértices. Procure escrever uma função limpa e eficiente. (Grafo completo)