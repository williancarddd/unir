O trabalho entrega tudo o que o enunciado pediu, entretanto, uma pequena modificação foi feita para
solucionar um problema de indexação. O valores de entradas foram reduzidos em -1 para cada vertice,
isso facilita a leitura e evita tratamentos dentro do código. O arquivo de entrada foi modificado para
isso. 