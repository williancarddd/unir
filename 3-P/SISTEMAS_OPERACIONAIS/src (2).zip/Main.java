
public class Main {

	public static void main(String[] args) {
		Pessoa p = new Pessoa();

		// Salário do estigiário
		p.setSalarioMensal(1.0);

		String minhaString = p.toString();

		System.out.println(minhaString);
	}

}
