public class Pessoa {
	private String nome = "Jonathan";
	private int idade = 18;
	
	private double salarioMensal;
	private double salarioAnual;

	public String toString() {
		String minhaString = 
				"Nome: " + this.nome + 
	"\nIdade: " + this.idade
	+ "\nSalarioMensal: " + this.salarioMensal +
	"\nSalarioAnual: " + this.getSalarioAnual();
		return minhaString;
	}
	
	/**
	 * Retorna o salário mensal multiplicado por 12
	 * 
	 * @param nenhum
	 * @return salário anual
	 */
	public double getSalarioAnual() {
		if (this.salarioMensal <= 0) {
			System.out.println("\nSem salario para calcular!");
		} else {
			this.salarioAnual = salarioMensal*12;
		}
		return salarioAnual;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public double getSalarioMensal() {
		return salarioMensal;
	}

	public void setSalarioMensal(double salarioMensal) {
		this.salarioMensal = salarioMensal;
	}

	private void setSalarioAnual(double salarioAnual) {
		this.salarioAnual = salarioAnual;
	}
}
