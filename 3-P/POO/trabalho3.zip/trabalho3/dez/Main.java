import java.util.Date;

public class Main {
  /**
 * @author William Cardoso Barbosa
 * @see williancard123@gmail.com
 */
  public static void main(String[] args) {
    Pessoa pessoa = new Pessoa("João", new Date(), 1.80f);
    System.out.println(pessoa);
  } 
}
