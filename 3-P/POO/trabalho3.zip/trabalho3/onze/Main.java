
public class Main {

  /*
    * @author William Cardoso Barbosa
    * @see williancard123@gmail.com
    */
  public static void main(String[] args) {
    Lampada lampada = new Lampada();
    lampada.acende();
    lampada.acende();
    lampada.apaga();
    lampada.apaga();
    lampada.imprimirEstado();
      
  }
}
