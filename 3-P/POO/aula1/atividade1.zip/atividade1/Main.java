
public class Main {
  public static void main(String[] args) { // todo programa inicia com public static void main(String args[])
    String name = "William";
    int age = 20;
    Person p4 = new Person();

    p4.setAge(age);
    p4.setName(name);
    p4.showPerson();
  }
}