
public class MeuFloat {
	private float nota;
	
	public MeuFloat(float nota) {
		this.nota = nota;
	}

	public float getNota() {
		return nota;
	}

	public void setNota(float nota) {
		this.nota = nota;
	}
}
