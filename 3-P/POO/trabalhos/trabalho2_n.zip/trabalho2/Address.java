public class Address {
    private String  country, city, state, zipCode, number,  more;
    
    public Address(String country, String city, String state, String zipCode) {
        this.country = country;
        this.city = city;
        this.state = state;
        this.zipCode = zipCode;
    }

    /*
     * exibe informações do endereço
     */
    public String toString(){
        return  "Country: "  + this.country +  " City: "  + this.city +  " State: "  + this.state +  " ZipCode: "  + this.zipCode + "\n";
    }
    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getMore() {
        return more;
    }

    public void setMore(String more) {
        this.more = more;
    }


}
