public class Product {
    private String description;
    private Double price;
    private Boolean worranty;

    public Product (String description, Double price, Boolean worranty) {
        this.description = description;
        this.price = price;
        this.worranty = worranty;
    }

    /*
     * exibe informações apenas do produto
     */
    public String toString() {
        return "Description: " + this.description + " Price: " + this.price + " Warranty: " + this.worranty + "\n";
    }
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Boolean getWorranty() {
        return worranty;
    }

    public void setWorranty(Boolean worranty) {
        this.worranty = worranty;
    }
}
