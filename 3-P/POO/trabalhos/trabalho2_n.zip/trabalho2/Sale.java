import java.util.Date;

//intermediary class


public class Sale extends Client {
    private Date saleDate;
    private String paymentType;
    private Product product;

    /*
     * A partir das tetativas de herança multipla, a qual o Java não tem suporte nativo
     * tendo em vista que ele não permite usar super() mais de uma vez e , também, pelo método 
     * da definição na mão , usando o this. , o qual ele não identifica como uma propriedade que
     * é da outra classe. Eu optei por fazer a classe receber um objeto Produto. 
     */
    public Sale(Date saleDate, String paymentType,
    String name, String document, String wirelesPhone ,Date birthDate, String email, String country, String city, String state, String zipCode,
                Product product) {
        super(name, document, wirelesPhone, birthDate, email, country, city, state, zipCode);
        this.product = product;
        this.saleDate = saleDate;
        this.paymentType = paymentType;
    }

    /**
     * Exibe informações apenas das vendas
     * exemplo
        * Sale Date: 2020-10-10 Payment Type: Credit Card
        * Name: João Document: 123.456.789-10 WirelesPhone: 11 99999-9999 Email:
    */
    public String toString() {
        return "Sale Date: " + this.saleDate + " Payment Type: " + this.paymentType + "\n" + this.product.toString() + super.toString();
    }
    public Date getSaleDate() {
        return saleDate;
    }

    public void setSaleDate(Date saleDate) {
        this.saleDate = saleDate;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }   
}   

